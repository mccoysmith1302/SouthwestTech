/*
Author: McCoy Smith
Date: 11/30/18
*/

import java.util.Scanner;
import java.math.*;

class FinalProject {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		//Enter the flavor you want
		System.out.println("What kind of flavor of ice cream do you want?");
		//input here
		String s = input.nextLine();
		//Enter the amount of toppings you want
		System.out.println("How many toppings would you like out of 20 different choices?");
		//input here
		int t = input.nextInt();
		while (t > 20) {
			System.out.println("Enter a new amount!");
			System.out.println();
			System.out.println("How many toppings would you like out of 20 different choices?");
			t = input.nextInt();
		}
		
		int topping = 20;
		int combinations = (int)(Math.random() * 20); 
		combins(t);
		//calculations here
		String [] toppingIs = {"Hot Fudge", "Caramel", "Butterscotch", "Strawberries", "Sprinkles", "Oreos", "Peanut Butter Cups", "Cookie Dough", "Whipped Cream", "Pecans", "Kiwi", "Pineapple", "Bananas", "Brownie Bites", "Coconut Flakes", "Honey", "Cashew", "Gummy Bears", "Reese's Pieces", "Chocolate Chips"};
		
		
		int count = 0;
		while(count < t){
			count++;
			int random = (int)(Math.random() * 20);
			System.out.println(toppingIs[random]);
		}
	}
	
	
	

	public static void combins(int t){
			int n = 20;
			int r = t;
			BigInteger ncr = (factorial(n).divide(factorial(n-r).multiply(factorial(r))));
			System.out.println("The total amount of options are: " + ncr);
		}	

	public static BigInteger factorial(int n){
		BigInteger fact = new BigInteger("1");
		for(int i = 1; i <= n; i++){
			fact = fact.multiply(new BigInteger(Integer.toString(i)));
		}
		return fact;
	}
	
}